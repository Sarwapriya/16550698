# System.Linq.Dynamic

- compiled for .NET 3.5
- packaged for NuGet